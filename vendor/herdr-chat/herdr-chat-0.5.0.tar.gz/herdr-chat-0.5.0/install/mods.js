import { createRequire as __herdrChatRequire } from 'node:module'; const require = __herdrChatRequire(import.meta.url);

// install/mods.ts
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
var HEADER = (from) => `// Herdr's shipped ${from}, copied by herdr-chat's install.sh. Don't edit: the next install replaces it.
`;
var DEFAULT_VIEW = /^export default class \w+ extends View\b/m;
function methodBody(src, name) {
  const m = new RegExp(`^(\\s+)${name}\\([^)]*\\)\\s*\\{`, "m").exec(src);
  if (!m) return null;
  const rest = src.slice(m.index + m[0].length);
  const next = new RegExp(`^${m[1]}(?:async\\s+)?[A-Za-z_]\\w*\\([^)]*\\)\\s*\\{`, "m").exec(rest);
  return next ? rest.slice(0, next.index) : rest;
}
function agentsBase(src) {
  if (!DEFAULT_VIEW.test(src)) return { ok: false, why: "mods/agents/main.js has no `export default class \u2026 extends View`" };
  const peek = methodBody(src, "peek");
  if (peek === null) return { ok: false, why: "mods/agents/main.js defines no peek(addr) method" };
  if (!/terminal\.peek/.test(peek)) return { ok: false, why: "mods/agents/main.js's peek() no longer runs terminal.peek" };
  const row = methodBody(src, "subRow");
  if (row === null) return { ok: false, why: "mods/agents/main.js has no subRow() (the sub-agent rows)" };
  if (!/on_click\([^)]*\)\s*=>[^\n]*this\.peek\(/.test(row)) return { ok: false, why: "a sub-agent row's click no longer calls this.peek(): the chat override would never run" };
  return { ok: true, base: HEADER("mods/agents/main.js") + src };
}
function menuBase(src) {
  if (!DEFAULT_VIEW.test(src)) return { ok: false, why: "mods/menu/main.js has no `export default class \u2026 extends View`" };
  if (methodBody(src, "render") === null) return { ok: false, why: "mods/menu/main.js has no render()" };
  return { ok: true, base: HEADER("mods/menu/main.js") + src };
}
var BASES = [
  { mod: "chat-agents", shipped: "agents", file: "agents-base.js", check: agentsBase },
  { mod: "chat-menu", shipped: "menu", file: "menu-base.js", check: menuBase }
];
function writeBases(shippedDir, stageDir) {
  const out = {};
  for (const b of BASES) {
    const src = join(shippedDir, b.shipped, "main.js");
    if (!existsSync(src)) {
      out[b.mod] = `no ${src} (start the app once, so it writes its own mods)`;
      continue;
    }
    const r = b.check(readFileSync(src, "utf8"));
    if (!r.ok) {
      out[b.mod] = r.why;
      continue;
    }
    if (existsSync(join(stageDir, b.mod))) writeFileSync(join(stageDir, b.mod, b.file), r.base);
    out[b.mod] = "ok";
  }
  return out;
}
if (true) {
  const [cmd, a, b] = process.argv.slice(2);
  if (cmd === "bases" && a && b) process.stdout.write(JSON.stringify(writeBases(a, b)) + "\n");
  else {
    process.stderr.write("usage: node install/mods.ts bases <shipped mods dir> <stage dir>\n");
    process.exit(2);
  }
}
export {
  BASES,
  agentsBase,
  menuBase,
  writeBases
};
