import { createRequire as __herdrChatRequire } from 'node:module'; const require = __herdrChatRequire(import.meta.url);

// install/instructions.ts
import { existsSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
var BEGIN = "<!-- herdr-chat:subagents begin -->";
var END = "<!-- herdr-chat:subagents end -->";
var BLOCK = [
  BEGIN,
  "## Sub-agents in Herdr",
  'To start a Pi, Claude Code or Codex sub-agent, run `hc run --bg --name <name> pi-chat "<task>"` (or `claude-chat`, `codex-chat`), so the person can open it as a chat.',
  "Use `hc run --bg --name <name> -- pi` (or `-- claude`, `-- codex`) only when you need its terminal UI.",
  "Everything else is the same: `hc send`, `hc wait`, `hc read` and `hc kill` by name.",
  END
].join("\n") + "\n";
function agents(env, home = env.HOME || homedir()) {
  const pi = env.PI_CODING_AGENT_DIR || join(home, ".pi", "agent");
  const claude = env.CLAUDE_CONFIG_DIR || join(home, ".claude");
  const codex = env.CODEX_HOME || join(home, ".codex");
  return [
    { id: "pi", name: "Pi", dir: pi, file: join(pi, "AGENTS.md") },
    { id: "claude", name: "Claude Code", dir: claude, file: join(claude, "CLAUDE.md") },
    { id: "codex", name: "Codex", dir: codex, file: join(codex, "AGENTS.md") }
  ];
}
function region(text) {
  const b = text.startsWith(BEGIN + "\n") ? 0 : text.indexOf("\n" + BEGIN + "\n") + 1;
  if (b <= 0 && !text.startsWith(BEGIN + "\n")) return null;
  const e = text.indexOf("\n" + END, b);
  if (e < 0) return null;
  let end = e + 1 + END.length;
  if (text[end] === "\n") end++;
  return [b, end];
}
function addBlock(text) {
  const r = region(text);
  if (r) return { text: text.slice(0, r[0]) + BLOCK + text.slice(r[1]), sep: null };
  const sep = text === "" || text.endsWith("\n\n") ? "" : text.endsWith("\n") ? "\n" : "\n\n";
  return { text: text + sep + BLOCK, sep };
}
function removeBlock(text, sep) {
  const r = region(text);
  if (!r) return text;
  let [b, e] = r;
  const before = sep ?? (text.slice(0, b).endsWith("\n\n") ? "\n" : "");
  if (before && text.slice(b - before.length, b) === before) b -= before.length;
  return text.slice(0, b) + text.slice(e);
}
var readRec = (f) => {
  try {
    return JSON.parse(readFileSync(f, "utf8"));
  } catch {
    return { files: {} };
  }
};
var isDir = (d) => {
  try {
    return statSync(d).isDirectory();
  } catch {
    return false;
  }
};
var writeWhole = (path, text) => writeFileSync(path, text);
function install(recFile, list) {
  const rec = readRec(recFile);
  const say = [];
  for (const a of list) {
    if (!isDir(a.dir)) {
      say.push(`${a.name}: no ${a.dir} (not installed): no sub-agents note`);
      continue;
    }
    const had = existsSync(a.file);
    const before = had ? readFileSync(a.file, "utf8") : "";
    const { text, sep } = addBlock(before);
    const prev = rec.files[a.file];
    rec.files[a.file] = sep === null && prev ? prev : { sep, created: !had };
    if (text !== before || !had) writeWhole(a.file, text);
    say.push(`${a.name}: ${text === before ? "the sub-agents note is up to date in" : sep === null ? "updated the sub-agents note in" : "added the sub-agents note to"} ${a.file}`);
  }
  writeFileSync(recFile, JSON.stringify(rec, null, 2) + "\n");
  return say;
}
function uninstall(recFile, list) {
  const rec = readRec(recFile);
  const say = [];
  for (const f of new Set(list.map((a) => a.file))) {
    if (!existsSync(f)) continue;
    const before = readFileSync(f, "utf8");
    const r = rec.files[f];
    const after = removeBlock(before, r?.sep);
    if (after === before) continue;
    if (after === "" && r?.created) {
      rmSync(f);
      say.push(`removed ${f} (the install made it)`);
    } else {
      writeWhole(f, after);
      say.push(`took the sub-agents note out of ${f}`);
    }
  }
  rmSync(recFile, { force: true });
  return say;
}
if (true) {
  const [cmd, home] = process.argv.slice(2);
  if (!home || cmd !== "install" && cmd !== "uninstall") {
    process.stderr.write("usage: node install/instructions.ts install|uninstall <app home>\n");
    process.exit(2);
  }
  const recFile = join(home, "data", "herdr-chat", "install-instructions.json");
  try {
    const lines = cmd === "install" ? install(recFile, agents(process.env)) : uninstall(recFile, agents(process.env));
    for (const l of lines) process.stdout.write(`herdr-chat: ${l}
`);
  } catch (e) {
    process.stderr.write(`herdr-chat: instructions: ${e instanceof Error ? e.message : e}
`);
    process.exit(1);
  }
}
export {
  BEGIN,
  BLOCK,
  END,
  addBlock,
  agents,
  install,
  removeBlock,
  uninstall
};
