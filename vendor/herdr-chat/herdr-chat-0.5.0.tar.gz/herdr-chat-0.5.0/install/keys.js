import { createRequire as __herdrChatRequire } from 'node:module'; const require = __herdrChatRequire(import.meta.url);

// install/keys.ts
import { existsSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
var NAMES = ["open", "pi", "claude", "codex", "continue"];
var ACTION = { open: "mod.open:new-chat", pi: "new-chat.pi", claude: "new-chat.claude", codex: "new-chat.codex", continue: "new-chat.continue" };
var TITLE = { open: "New chat", pi: "Pi chat", claude: "Claude Code chat", codex: "Codex chat", continue: "Continue as chat" };
function defaults(platform) {
  return platform === "darwin" ? { open: "cmd-i", fallback: "cmd-j a" } : { open: "ctrl-alt-shift-p", fallback: null };
}
function pretty(chord, platform) {
  const mac = platform === "darwin";
  const SYM = mac ? { cmd: "\u2318", ctrl: "\u2303", alt: "\u2325", shift: "\u21E7" } : { cmd: "Ctrl+", ctrl: "Ctrl+", alt: "Alt+", shift: "Shift+" };
  const KEY = { enter: "\u21A9", escape: "Esc", space: "Space", tab: "\u21E5", backspace: "\u232B", up: "\u2191", down: "\u2193", left: "\u2190", right: "\u2192" };
  return chord.split(" ").map((step) => {
    const parts = step.endsWith("--") ? [...step.slice(0, -2).split("-"), "-"] : step.split("-");
    const key = parts.pop();
    const k = KEY[key] ?? (key.length === 1 ? key.toUpperCase() : key.charAt(0).toUpperCase() + key.slice(1));
    return parts.map((m) => SYM[m] ?? `${m}+`).join("") + k;
  }).join(" ");
}
function readPrefs(raw) {
  const prefs = {};
  const errors = [];
  const g = raw?.global;
  if (g === void 0) return { prefs, errors };
  if (!g || typeof g !== "object" || Array.isArray(g)) return { prefs, errors: ['"global" is not an object: the defaults apply'] };
  for (const [k, v] of Object.entries(g)) {
    if (!NAMES.includes(k)) {
      errors.push(`"global": unknown "${k}" (known: ${NAMES.join(", ")})`);
      continue;
    }
    const list = v === null ? null : typeof v === "string" ? [v] : Array.isArray(v) && v.every((x) => typeof x === "string") ? v : void 0;
    if (list === void 0) {
      errors.push(`"global"."${k}": a chord, a list of chords or null`);
      continue;
    }
    const bad = (list ?? []).filter((c) => !c.trim() || c !== c.trim());
    if (bad.length) {
      errors.push(`"global"."${k}": not a chord: ${JSON.stringify(bad[0])}`);
      continue;
    }
    prefs[k] = list;
  }
  return { prefs, errors };
}
function owned(rec) {
  return { ...rec?.global ?? {} };
}
function restore(g, own) {
  const out = [];
  for (const [k, { action, was }] of Object.entries(own)) {
    if (g[k] !== action) continue;
    if (was == null) delete g[k];
    else g[k] = was;
    out.push(k);
  }
  return out;
}
function apply(doc, rec, o) {
  const g = doc.global ??= {};
  restore(g, owned(rec));
  const own = {};
  const lines = [];
  const bound = {};
  const p = (c) => pretty(c, o.platform);
  const term = doc.terminal ?? {};
  const bind = (n, chord) => {
    const was = g[chord];
    if (own[chord]) {
      lines.push(`${TITLE[n]}: ${p(chord)} is another chat key's already; not bound twice`);
      return;
    }
    if (was !== void 0 && was !== ACTION[n]) lines.push(`${TITLE[n]}: ${p(chord)} replaces ${was} (uninstall puts it back)`);
    g[chord] = ACTION[n];
    own[chord] = { action: ACTION[n], was: was ?? null };
    if (term[chord] && term[chord] !== "terminal") lines.push(`${TITLE[n]}: in a terminal, ${p(chord)} is the terminal section's ${term[chord]}`);
    bound[n] ??= chord;
  };
  for (const n of NAMES) {
    const chosen = o.prefs[n];
    if (n !== "open" && !o.direct && chosen?.length) {
      lines.push(`${TITLE[n]}: ${chosen.map(p).join(", ")} not bound: it needs the layout's new-chat copy (install without --no-layout)`);
      continue;
    }
    if (chosen === null) continue;
    if (chosen !== void 0) {
      for (const c of chosen) bind(n, c);
      continue;
    }
    if (n !== "open") continue;
    const d = defaults(o.platform);
    const free = (c) => g[c] === void 0 || g[c] === ACTION.open;
    if (free(d.open)) bind(n, d.open);
    else if (d.fallback && free(d.fallback)) {
      lines.push(`${p(d.open)} is taken (${g[d.open]}): New chat is ${p(d.fallback)} instead. To choose: "global": {"open": "<chord>"} in data/herdr-chat/keys.json, then install again`);
      bind(n, d.fallback);
    } else lines.push(`${p(d.open)}${d.fallback ? ` and ${p(d.fallback)} are` : " is"} taken: New chat has no key. To choose: "global": {"open": "<chord>"} in data/herdr-chat/keys.json, then install again`);
  }
  return { own, lines, bound };
}
function summary(bound, platform) {
  const parts = NAMES.filter((n) => bound[n]).map((n) => `${TITLE[n]}: ${pretty(bound[n], platform)}`);
  return parts.length ? parts.join(" \xB7 ") : "New chat: no key (Herdr's mod.open:new-chat opens it)";
}
function editKeys(path, edit) {
  for (let i = 0; i < 5; i++) {
    const before = existsSync(path) ? readFileSync(path, "utf8") : null;
    const doc = before === null ? {} : JSON.parse(before);
    const was = JSON.stringify(doc);
    edit(doc);
    if (JSON.stringify(doc) === was) return false;
    const tmp = join(path, "..", ".keys.json.herdr-chat.tmp");
    writeFileSync(tmp, JSON.stringify(doc, null, 2) + "\n");
    if ((existsSync(path) ? readFileSync(path, "utf8") : null) !== before) {
      rmSync(tmp, { force: true });
      continue;
    }
    renameSync(tmp, path);
    return true;
  }
  throw new Error(`${path} keeps changing; run the install again`);
}
var readJson = (f) => {
  try {
    return JSON.parse(readFileSync(f, "utf8"));
  } catch {
    return null;
  }
};
function install(home, o) {
  const state = join(home, "data", "herdr-chat");
  const recFile = join(state, "install.json");
  const mine = existsSync(join(state, "keys.json")) ? readJson(join(state, "keys.json")) : {};
  const lines = [];
  if (mine === null) lines.push("data/herdr-chat/keys.json isn't valid JSON: the default keys apply");
  const { prefs, errors } = readPrefs(mine ?? {});
  lines.push(...errors.map((e) => `data/herdr-chat/keys.json: ${e}`));
  let plan = { own: {}, lines: [], bound: {} };
  const rec = readJson(recFile);
  editKeys(join(home, "keys.json"), (doc) => {
    plan = apply(doc, rec, { prefs, platform: o.platform, direct: o.direct });
  });
  writeFileSync(recFile, JSON.stringify({ version: 2, global: plan.own }, null, 2) + "\n");
  return [...lines, ...plan.lines, `=${summary(plan.bound, o.platform)}`];
}
function uninstall(home) {
  const recFile = join(home, "data", "herdr-chat", "install.json");
  const rec = readJson(recFile);
  let undone = [];
  if (existsSync(join(home, "keys.json"))) editKeys(join(home, "keys.json"), (doc) => {
    undone = restore(doc.global ?? {}, owned(rec));
  });
  rmSync(recFile, { force: true });
  return [undone.length ? `keys: ${undone.join(", ")} back to what they were` : "keys: nothing of ours in keys.json"];
}
if (true) {
  const [cmd, home, ...rest] = process.argv.slice(2);
  const value = (f) => {
    const i = rest.indexOf(f);
    return i >= 0 ? rest[i + 1] ?? null : null;
  };
  if (!home || cmd !== "install" && cmd !== "uninstall") {
    process.stderr.write("usage: node install/keys.ts install|uninstall <app home> [--no-direct] [--platform darwin|linux]\n");
    process.exit(2);
  }
  try {
    const lines = cmd === "install" ? install(home, { direct: !rest.includes("--no-direct"), platform: value("--platform") ?? process.platform }) : uninstall(home);
    for (const l of lines) process.stdout.write(l.startsWith("=") ? `${l.slice(1)}
` : `herdr-chat: ${l}
`);
  } catch (e) {
    process.stderr.write(`herdr-chat: keys: ${e instanceof Error ? e.message : e}
`);
    process.exit(1);
  }
}
export {
  ACTION,
  NAMES,
  TITLE,
  apply,
  defaults,
  install,
  owned,
  pretty,
  readPrefs,
  restore,
  summary,
  uninstall
};
