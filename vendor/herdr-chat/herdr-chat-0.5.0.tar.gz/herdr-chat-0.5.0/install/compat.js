import { createRequire as __herdrChatRequire } from 'node:module'; const require = __herdrChatRequire(import.meta.url);

// install/compat.ts
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var COMPAT = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), "..", "package.json"), "utf8")).herdr;
var INSTALL = process.env.HERDR_CHAT_INSTALL_CMD || "./install.sh";
var UNINSTALL = `If something breaks, \`${INSTALL} --uninstall\``;
function versionOf(bin) {
  const r = spawnSync(bin, ["--version"], { encoding: "utf8", timeout: 5e3 });
  return r.status === 0 ? /(\d+\.\d+\.\d+)/.exec(r.stdout)?.[1] ?? null : null;
}
function compare(a, b) {
  const p = (v) => v.split(/[.-]/).slice(0, 3).map((n) => parseInt(n, 10) || 0);
  const [x, y] = [p(a), p(b)];
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] - y[i];
  return 0;
}
function decide(v, c = COMPAT) {
  const warn = [];
  if (v.app === null) warn.push(`can't tell Herdr's version (herdr-app --version said nothing usable): tested with ${c.tested.app}. ${UNINSTALL}`);
  else if (compare(v.app, c.minimum.app) < 0) return { refuse: `Herdr ${v.app} is older than ${c.minimum.app}, the oldest the chat works with (${c.minimum.why}). Update Herdr, then run ${INSTALL} again.`, warn };
  else if (compare(v.app, c.tested.app) > 0) warn.push(`Herdr ${v.app} is newer than the tested ${c.tested.app}. ${UNINSTALL}`);
  if (v.core === null) warn.push(`can't tell herdr-core's version (hc --version said nothing usable): tested with ${c.tested.core}. ${UNINSTALL}`);
  else if (compare(v.core, c.tested.core) > 0) warn.push(`herdr-core ${v.core} is newer than the tested ${c.tested.core}. ${UNINSTALL}`);
  return { refuse: null, warn };
}
if (true) {
  const [cmd, ...rest] = process.argv.slice(2);
  const value = (f) => {
    const i = rest.indexOf(f);
    return i >= 0 ? rest[i + 1] ?? null : null;
  };
  if (cmd === "app-version" && rest[0]) {
    process.stdout.write((versionOf(rest[0]) ?? "unknown") + "\n");
  } else if (cmd === "check" && value("--app") && value("--hc")) {
    const r = decide({ app: versionOf(value("--app")), core: versionOf(value("--hc")) });
    for (const w of r.warn) process.stdout.write(`herdr-chat: ${w}
`);
    if (r.refuse) {
      process.stderr.write(`herdr-chat: ${r.refuse}
`);
      process.exit(1);
    }
  } else {
    process.stderr.write("usage: node install/compat.ts check --app <herdr-app> --hc <hc> | app-version <herdr-app>\n");
    process.exit(2);
  }
}
export {
  COMPAT,
  compare,
  decide,
  versionOf
};
